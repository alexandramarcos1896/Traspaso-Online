%%% adjust elast=4

clear all
close all
clc

tic

global D beta theta kappa epsilon

epsilon=4;

%%% Parameters
beta=0.96^(1/12);
D=1;
theta=5;
% kappa=0.025;

min_p=-0.13;
max_p=0.52;
N_p = round((max_p-min_p)*100)*2+1;
Grid_p = linspace(min_p,max_p,N_p)';

min_P=0.21;
max_P=0.25;
N_P = 25;
Grid_P = linspace(min_P,max_P,N_P)';


N_A=11;
rho_A=0.95;
sigma_A=0.085;
m_A=2.5;
[Grid_A TPM_A] = tauchen(N_A,0,rho_A,sigma_A,m_A);
A_dist_ss = [Grid_A mean(TPM_A^100)'];
min_A=Grid_A(1);
max_A=Grid_A(end);

N_E=15;
dE=0.025;
max_E = (N_E-1)/2*dE;
min_E = - max_E;
Grid_E = linspace(min_E,max_E,N_E)';
TPM_E = [.5; .5];

omega=.2;
N_phi=2;
Grid_phi = [0; 0.75];
Pr_phi = [1/(1+omega); omega/(1+omega)];

N_kappa=3;
Grid_kappa = [0.0125; 0.025; 0.05];
Pr_phi = [1/3; 1/3; 1/3];


Forecast = [0.0923; 0.5910; 0.0495];

NRC = RD(0,0)*exp(Grid_P((N_P+1)/2));


FlowV;
[FFFmax ind_p_flex]=max(FFF,[],1);
p_flex = permute(Grid_p(ind_p_flex),[2 3 4 5 1]);

toc
tic

precision = 1e-3;
FFF=repmat(FFF,[1 1 1 1 1 N_kappa]);
V0 = FFF/(1-beta);
Bellman;

save V

display('Value Function')
toc
tic


N=12000;
T=240;

KAPPA = repmat([1; 2; 3],N*(1+omega)/3,1);
PHI = [ones(N,1); 2*ones(N*omega,1)];
N=N*(1+omega);

uA=randn(N,1);
indA(1,:) = index(uA*sigma_A/sqrt(1-rho_A^2),min_A,max_A,N_A)';
for t=2:T;
    uA=randn(N,1);
    indA(t,:) = index( rho_A*( Grid_A(indA(t-1,:)) ) + uA*sigma_A, min_A,max_A,N_A)';
end



indE(1,1) = (N_E+1)/2;
for t=2:T;
    
    u_E=rand;
    i=1;
    while u_E>sum(TPM_E(1:i))
        i=i+1;
    end;
    
    if i==1
        indE(t,1) = min(indE(t-1,1)+1,N_E);
    else
        indE(t,1) = max(indE(t-1,1)-1,1);
    end
    
end


% indE = [(N_E+1)/2*ones(T/3,1); ((N_E+1)/2+6)*ones(2*T/3,1)];


indPR=[];
indP=[];

for i = 1:N;
    indPR_tmp(i,:) = ind_des(1,:,indA(1,i),indE(1),PHI(i),KAPPA(i));
end
tP = mean(Grid_p(indPR_tmp));
if Grid_P(end)<tP(end)
    i=N_P;
else
    i=1;
    while Grid_P(i)<tP(i)
        i=i+1;
    end
    if abs(Grid_P(i)-tP(i))>abs(Grid_P(max(i-1,1))-tP(max(i-1,1)))
        i=i-1;
    end
end
indP = i;
indPR = indPR_tmp(:,i)';



for t=2:T;
    
    t;
    
    for i = 1:N;
        indPR_tmp(i,:) = ind_p(indPR(t-1,i),:,indA(t,i),indE(t),PHI(i),KAPPA(i));
    end
    tP = mean(Grid_p(indPR_tmp));
    if Grid_P(end)<tP(end)
        i=N_P;
    else
        i=1;
        while Grid_P(i)<tP(i)
            i=i+1;
        end
        if abs(Grid_P(i)-tP(i))>abs(Grid_P(max(i-1,1))-tP(max(i-1,1)))
            i=i-1;
        end
    end
    indP = [indP; i];
    indPR = [indPR; indPR_tmp(:,i)'];
        
end


figure(3)
subplot(1,2,1)
plot((1:T)',[indP min(indPR')' max(indPR')'])
subplot(1,2,2)
plot((1:T)',Grid_P(indP))

figure(1)
plot((1:T)', [Grid_P(indP)-mean(Grid_P(indP)) mean(Grid_A(indA)')' Grid_E(indE')])


YYY = Grid_P(indP);
XXX = [ones(T-1,1) YYY(1:T-1) Grid_E(indE(2:end)')];
YYY2 = YYY(2:end);
Forecast_new = (XXX'*XXX)\XXX'*YYY2
e1=YYY2 - XXX*Forecast;
e2=YYY2 - XXX*Forecast_new;
IMP=(e1'*e1-e2'*e2)/(e1'*e1)


T=120;
indA = indA(end-T+1:end,:);
indE = indE(end-T+1:end,:);
indP = indP(end-T+1:end,:);
indPR = indPR(end-T+1:end,:);

FREQ=[mean(mean(abs(sign(indPR(2:end,1:N/(1+omega))-indPR(1:end-1,1:N/(1+omega))))));...
    mean(mean(abs(sign(indPR(2:end,N/(1+omega)+1:N)-indPR(1:end-1,N/(1+omega)+1:N)))))]

mean(mean(abs(sign(indPR(2:end,:)-indPR(1:end-1,:)))))


SIZE = [mean(mean(abs(Grid_p(indPR(2:end,1:N/(1+omega)))-Grid_p(indPR(1:end-1,1:N/(1+omega))))))/...
    mean(mean(abs(sign(indPR(2:end,1:N/(1+omega))-indPR(1:end-1,1:N/(1+omega))))));
    mean(mean(abs(Grid_p(indPR(2:end,N/(1+omega)+1:N))-Grid_p(indPR(1:end-1,N/(1+omega)+1:N)))))/...
    mean(mean(abs(sign(indPR(2:end,N/(1+omega)+1:N)-indPR(1:end-1,N/(1+omega)+1:N)))))]

SSS = abs(Grid_p(indPR(2:end,N/(1+omega)+1:end))-Grid_p(indPR(1:end-1,N/(1+omega)+1:end)));
SSS = sort(SSS(1:end)');
SIZE_5 = SSS(end- ...
    round(sum(sum(abs(sign(indPR(2:end,N/(1+omega)+1:N)-indPR(1:end-1,N/(1+omega)+1:N)))))*95/100))/SIZE(2)
SIZE_10 = SSS(end- ...
    round(sum(sum(abs(sign(indPR(2:end,N/(1+omega)+1:N)-indPR(1:end-1,N/(1+omega)+1:N)))))*90/100))/SIZE(2)
SIZE_25 = SSS(end- ...
    round(sum(sum(abs(sign(indPR(2:end,N/(1+omega)+1:N)-indPR(1:end-1,N/(1+omega)+1:N)))))*75/100))/SIZE(2)

N_p

display('simulation of prices')
toc