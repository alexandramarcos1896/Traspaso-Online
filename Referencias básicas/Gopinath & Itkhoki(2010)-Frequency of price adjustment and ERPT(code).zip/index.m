%%% Finds index on the grid

function [indX] = index(X,minX,maxX,NX)

indX = 1 + max(round( (NX-1) * ( min(X,maxX)-minX )./(maxX-minX) ),0);