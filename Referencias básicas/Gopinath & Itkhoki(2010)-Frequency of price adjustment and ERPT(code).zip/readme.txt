
tauchen.m 	: discretization of AR(1)

index.m 	: discretization on a grid

RD.m 		: Kimball demand function

Profit.m 	: profit function

FlowV.m		: computes profits on a state-space grid

Bellman.m	: Bellman operator, solves for value and policy functions

Start.m		: initial run to check grids, produces policy function and price series

full_auto.m,
Forecasting.m	: upper-tier iteration to find the forecasting rule

main.m 		: lower-tier simulation, given forecasting rule and grids produces a panel of prices