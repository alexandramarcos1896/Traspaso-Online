%%% Bellman Operator iteration for policy function
% Input: V0
% Output: V V_N V_A ind_des ind_p

V_N = V0;
V_A = max(V_N,[],1);
V_A = repmat(V_A,N_p,1);
for i=1:N_kappa;
    V(:,:,:,:,:,i) = max(V_N(:,:,:,:,:,i),V_A(:,:,:,:,:,i)-NRC*Grid_kappa(i));
end
V0 = V;


counter=0;
delta=1;
while delta>precision;


    EV = zeros(size(V0));
    EV2 = zeros(size(V0));

    for i=1:N_A;
        for j=1:N_A;

            EV(:,:,i,:,:,:) = EV(:,:,i,:,:,:) + TPM_A(i,j)*V0(:,:,j,:,:,:);

        end;
    end;


    for i=1:N_E;
        for k=1:N_P;

                i1=min(i+1,N_E);
                k1 = index([1 Grid_P(k) Grid_E(i1)]*Forecast,min_P,max_P,N_P);

                i2=max(i-1,1);
                k2 = index([1 Grid_P(k) Grid_E(i2)]*Forecast,min_P,max_P,N_P);

                EV2(:,k,:,i,:,:) =EV2(:,k,:,i,:,:) +TPM_E(1)*EV(:,k1,:,i1,:,:) +TPM_E(2)*EV(:,k2,:,i2,:,:);

        end;
    end;

    V_N = FFF + beta*EV2;
    V_A = max(V_N,[],1);
    V_A = repmat(V_A,N_p,1);
    for i=1:N_kappa;
        V(:,:,:,:,:,i) = max(V_N(:,:,:,:,:,i),V_A(:,:,:,:,:,i)-NRC*Grid_kappa(i));
    end
    delta = max(max(max(max(max(max(abs(V-V0)./(abs(V0)+eps)))))));
    V0=V;
    counter=counter+1;
%     [counter delta]       
end;



% figure(1)
% plot(Grid_p,permute(V(:,(N_P+1)/2,(N_A+1)/2,(N_E+1)/2,2,:),[1 6 2 3 4 5]))
% pause

[tmp ind_des] = max(V_N,[],1);
ind_p = repmat(ind_des,N_p,1);
ind_p_old = repmat((1:N_p)',[1 N_P N_A N_E N_phi N_kappa]);
ADJ = V - V_N;
ADJ(ADJ>0) = 1;
ind_p = ADJ.*ind_p + (1-ADJ).*ind_p_old;