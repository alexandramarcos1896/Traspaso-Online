%%% Profit function

function [f] = Profit(p,P,a,e,phi)

f = ( exp(p) - exp(phi*e-a) ) .* RD(p,P);