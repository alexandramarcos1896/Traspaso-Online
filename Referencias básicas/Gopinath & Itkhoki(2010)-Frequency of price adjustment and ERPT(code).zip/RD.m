%%% Kimball (Relative) Demand Function

function [f] = RD(p,P)

global D theta epsilon

if epsilon==0;
    f = exp(-theta*(p - P));
else;
    f = ( max(0, 1 + epsilon * log( D * exp(P-p) )) ).^( theta/epsilon ) ;
end;