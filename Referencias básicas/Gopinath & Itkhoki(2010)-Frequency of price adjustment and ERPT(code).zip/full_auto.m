%%% full-auto elast=4

clear all
close all
clc

min_p=-0.13;
max_p=0.52;
N_p = max(101,round((max_p-min_p)*50)*2+1);
Grid_p = linspace(min_p,max_p,N_p)';

min_P=0.205;
max_P=0.255;
N_P = 31;
Grid_P = linspace(min_P,max_P,N_P)';


Forecast = [0.08; 0.6; 0.04];

improv = 1;
while improv<1e-1; %%% Value of a respective chi distribution (other measures of convergence also possible)

    Forecasting
    Forecast = mean(Forecast_Rule)'

end

tic
precision = 1e-2;
Bellman;

display('Value Function')
toc


save Policy_e4 Grid_p Grid_P ind_des ind_p
