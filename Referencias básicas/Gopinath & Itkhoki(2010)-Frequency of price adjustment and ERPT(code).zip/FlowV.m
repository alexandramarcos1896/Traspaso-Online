%%% Computes Flow Value (profit) on a grid

for i2=1:N_P;
    for i3=1:N_A;
        for i4=1:N_E;
            for i5=1:N_phi;
            
                FFF(:,i2,i3,i4,i5) = Profit(Grid_p,Grid_P(i2),Grid_A(i3),...
                    Grid_E(i4),Grid_phi(i5));
                
            end;
        end;
    end;
end;